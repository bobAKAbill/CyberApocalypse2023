import socket
import time
import random
from ctypes import CDLL
from ctypes.util import find_library

def read_until(s, delim=b':'):
    buf = b''
    s.settimeout(1)
    while not buf.endswith(delim):
        try:
            buf += s.recv(1)
        except:
            break

    s.settimeout(None)

    return buf.decode("utf8")

libc = CDLL("libc.so.6")

guru_choices = ["rock", "scissors", "paper"]
player_choices = ["paper", "rock", "scissors"]

#68.183.37.122:30000

host = "68.183.37.122"
port = 30000
#host = "127.0.0.1"
#port = 6969

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((host, port))
time.sleep(0.5)
printout = bytearray.fromhex(s.recv(2048).hex()).decode()
print(printout)

if(">>" in printout):
	print("connection successful")
	s.sendall(b'1')
	printout = read_until(s, b">>")
	print(printout)
	firstTime = libc.time()
	libc.srand(firstTime)
	firstRand = libc.rand()%3
else:
	exit()

win_count = 0
print("starting game")
while(True):
	if(win_count == 0):
		randint = firstRand
	else:
		timeVar = libc.time()
		libc.srand(timeVar)
		randint = libc.rand()%3

	guru_choice = guru_choices[randint]
	choice = player_choices[randint]
	s.send(choice.encode())
#	print("guru chooses", guru_choice)
#	print(choice, "sent")
	printout = read_until(s, b">>")
	print(printout)

	if("lost" in printout):
		#print("I lost :(")
		break
	if("won" in printout):
		win_count = win_count + 1
		#print("I won", win_count, "times!")
		continue
