from web3 import Web3
from solcx import compile_standard
TCP_IP = "167.71.143.44"
TCP_PORT = "32038"
RPC_IP = "167.71.143.44"
RPC_PORT = "32452"

private_key = "0xc6724676c0a02e94d7f7d47291fbc0ed5a2298b10896d31b2683aa01409faaa7"
address = "0x3dfd8Afcbf2DF2453B62d7CB35F708b5065085ff"
target_contract = "0x18798d8D39d710846fCa093f05B7D0Aa2f5AE00a"
setup_contract = "0x3Cd3c3D039aEc39Eb376513d689BA5D053684783"

# Fill in your infura API key here
infura_url = RPC_IP + ":" + RPC_PORT + "/" + private_key
print(infura_url)
web3 = Web3(Web3.HTTPProvider(infura_url))

'''
compiled_sol = compile_standard(
	{
		"language": "Solidity",
		"sources": {"Setup1.sol": {"content": 
'''
print(web3.is_connected())

print(web3.eth.block_number)

# Fill in your account here
balance = web3.eth.getBalance("YOUR_ACCOUNT_GOES_HERE")
print(web3.fromWei(balance, "ether"))
