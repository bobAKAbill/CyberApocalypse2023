import numpy as np
import soundfile as sf

flag, flagrate = sf.read('./shuffled_flag.wav')
impulse, impulserate = sf.read('./impulse_response.wav')

# randomly shuffle the frequencies
freqs = np.fft.rfftfreq(len(flag), 1.0/flagrate)
filter_frequency_response = np.random.uniform(-10, 10, len(freqs))

# get the amplitudes
def filter(sample):
	amplitudes = np.fft.rfft(sample)
	print(amplitudes[0])
	print(amplitudes[1])
	shuffled_amplitudes = amplitudes * filter_frequency_response
	return np.fft.irfft(shuffled_amplitudes)


def unfilter(sample):
	amplitudes = np.fft.rfft(sample)
	print(amplitudes[0])
	print(np.real(amplitudes[0]))
	print(amplitudes[1])
	print(np.real(amplitudes[1]))
	original_filter_frequency_response = np.real(amplitudes)
	return original_filter_frequency_response

def flag_back(sample):
	amplitudes = np.fft.rfft(sample)
	print(amplitudes[0])
	print(amplitudes[1])
	original_amplitudes = amplitudes / original_multiplier
	return np.fft.irfft(original_amplitudes)

original_multiplier = unfilter(impulse)
print(original_multiplier)
print(filter_frequency_response)
flag_returned = flag_back(flag)
print(flag_returned)
#shuffled_signal = filter(impulse)
#sf.write('impulse_response.wav', shuffled_signal, rate)

#shuffled_flag = filter(flag)
#sf.write('shuffled_flag.wav', shuffled_flag, rate)
sf.write('flag.wav', flag_returned, flagrate)
